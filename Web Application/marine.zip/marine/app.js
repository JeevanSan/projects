import React,{Component} from 'react';

import Second from './componet/Second';
import Demo from './componet/demo';
import Addtion from './componet/Addtion'
import Home from './componet/Home';
import Navi from './componet/Navi';
import Abcd from './componet/Abcd';
import Login from './componet/login';
import Video2 from './componet/Video1';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TouchableWithoutFeedback,
  Picker,
  ToastAndroid,
  ProgressBarAndroid
} from 'react-native';

export default class App extends React.Component {


  render() {

    return (
     <View style={styles.container}>
       <Video2/>
     </View>
        
    );
  }
}
 const styles = StyleSheet.create({
   container: {
     flex: 1,
     alignItems: 'center',
     justifyContent: 'center'
   }

 })
