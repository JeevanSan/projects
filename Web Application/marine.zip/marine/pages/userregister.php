<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
</head>
<!-- ============================================================== -->
<!-- signup form  -->
<!-- ============================================================== -->

<body>
    <!-- ============================================================== -->
    <!-- signup form  -->
    <!-- ============================================================== -->
	
	<?php
  error_reporting(0);
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['p1'])){
		$p1 = stripslashes($_REQUEST['p1']); // removes backslashes
		$p1 = mysqli_real_escape_string($con,$p1); //escapes special characters in a string
		$p2 = stripslashes($_REQUEST['p2']);
		$p2 = mysqli_real_escape_string($con,$p2);
		$p3 = stripslashes($_REQUEST['p3']); // removes backslashes
		$p3 = mysqli_real_escape_string($con,$p3);
		$p4 = stripslashes($_REQUEST['p4']);
		$p4 = mysqli_real_escape_string($con,$p4);		

		

		
		
		 $query = mysqli_query($con, "SELECT * FROM users WHERE username = '".$p1. "'");
  if(mysqli_num_rows(  $query) > 0){
   echo "<div class='form'><h3>!!!!!!!!!!! user name already exist please user other.</h3><br/>Click here to try again <a href='userregister.php'>Register</a></div>";
}
else{
 $query = "INSERT into `users` (username, email, phone, password) VALUES ('$p1', '$p2', '$p3', '$p4')";
        $result = mysqli_query($con,$query);
}
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='userlogin.php'>Login</a></div>";
           
        }
    }else{
		?>
    <form class="splash-container"  name="userregister" action="" method="post">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1">Registrations Form</h3>
                <p>Please enter your user information.</p>
            </div>
		
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text" name="p1" required="" placeholder="Username" autocomplete="off">
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="email" name="p2" required="" placeholder="E-mail" autocomplete="off">
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="text"  name="p3" required="" placeholder="Phone">
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" type="password" name="p4" required="" placeholder="Password">
                </div>
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit">Register My Account</button>
                </div>
              
            
            </div>
            <div class="card-footer bg-white">
                <p>Already member? <a href="userlogin.php" class="text-secondary">Login Here.</a></p>
            </div>
        </div>
    </form>
		<?php } ?>
</body>

 	
</html>