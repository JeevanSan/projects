<?php


include("auth.php"); //include auth.php file on all secure pages ?><html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Marine Harvesting</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="index.html">Marine Harvesting</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="userdash.php">Dashboard</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="searchproduct.php">Search Product</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sendfeedback.php">Send Feedback</a>
                                        </li>
										<li class="nav-item">
                                            <a class="nav-link" href="userlogout.php">Logout</a>
                                        </li>
                                    </ul>
                              
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
		 <div class="row">
                        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3>Search Product</h3>
                                    </div>
									 <form class="row"  action="" method="post">
                                    <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Region</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select name="p1" class="form-control form-control-sm">
                                                    <option>GOA</option>
													<option>GUJARAT</option>
													<option>TAMIL NADU</option>
													<option>KERALA</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Fish Type</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select name="p2" class="form-control form-control-sm">
                                                    <option>Restrected</option>
													<option>Suggested</option>
                                                </select>
                                            </div>
                                        </div>
										<button type="submit" class="btn btn-space btn-primary">Search</button>
                                </div>
								 </form>
                            </div>
							</div>
                                </div>
                            </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
         <?php
	 error_reporting(0);
	 $a=$_POST['p1'];
	 $b=$_POST['p2'];
	 $query="SELECT * from product where region='$a' and fish_type='$b'";
$mysql_hostname = "localhost";
$mysql_user     = "root";
$mysql_password = "";
$mysql_database = "marine";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database);
if(mysqli_connect_errno())
{
	echo"failed to connect to MysQl: ". mysqli_connect_error();
}
$result = mysqli_query($con,$query); // selecting data through mysql_query()


?>
		
										
	<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Product Details </h2>
                                
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
					<?php 
										while($data = mysqli_fetch_array($result))
{

	?>
                    <div class="row">
                        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-header p-4">
                                     <a class="pt-2 d-inline-block">Product Id : <?php echo $data['id']; ?></a>
                                   
                                    <div class="float-right"> <h3 class="mb-0"></h3>
                                    Date: <?php echo $data['pdate']; ?></div>
                                </div>
								<form action="sendrequest.php" name="" method="post" >
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-sm-6">
                                            <h5 class="mb-3">UserName:</h5>                                            
                                            <h3 class="text-dark mb-1"><input name="p1" type="text" value="<?php echo $_SESSION['username']; ?>" readonly></h3>
											
											<h5 class="mb-3">FisherMan Name:</h5>                                            
                                            <h3 class="text-dark mb-1"><input name="p11" type="text" value="<?php echo $data['fisherman_name']; ?>" readonly></h3>
                                         
                                      
                                        </div>
                                        <div class="col-sm-6">
                                            <h5 class="mb-3">Image:</h5>
                                            <img src="assets\images\<?php echo $data['photo']; ?>">
                                        </div>
                                    </div>
                                    <div class="table-responsive-sm">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    
                                                    <th>Region</th>
                                                    <th>Fish Type</th>
                                                    <th class="right">No Of KG</th>
                                                    <th class="center">Price</th>
                                                    <th class="right">About</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    
                                                    <td class="left strong"><?php echo $data['region']; ?></td>
                                                    <td class="left"><?php echo $data['fish_type']; ?></td>
                                                    <td class="right"><?php echo $data['no_of_kg']; ?></td>
                                                    <td class="center"><?php echo $data['price']; ?></td>
                                                    <td class="right"><?php echo $data['about']; ?></td>
                                                </tr>
                                                <tr>

                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row">
                                        
                                    </div>
                                </div>
                                <div class="card-footer bg-white">
                                    <div class="col-lg-8 col-sm-5">
										<textarea name="p2" class="form-control" id="exampleFormControlTextarea1" placeholder=" Enter Message"  rows="3"></textarea>

                                        </div>
										</div>
                                        <div class="card-footer bg-white">
                                        <div class="col-lg-4 col-sm-5">
                                            
										<button type="submit" class="btn btn-primary btn-block">Bid</button>
                                        </div>
                                </div>
								</form>
                            </div>
                        </div>
                    </div>
                
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            
                                       
<?php } ?>
           </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
    </div>                         
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>