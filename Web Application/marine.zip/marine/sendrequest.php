<?php 
$db="marine";
$user="root";
$pass="";
$server="localhost";
$aa=$_POST['p12'];
$a=$_POST['p11'];
$b=$_POST['p1'];
$c=$_POST['p2'];



$con=mysqli_connect($server,$user,$pass,$db);

if($con){
	
	$sql="INSERT INTO prequest(`pid`, `fisher_man`, `username`, `message`) VALUES ('$aa', '$a', '$b', '$c')";
	if($con->query($sql)===TRUE){
		echo"Record inserted";?>
		<script type="text/javascript">
            window.alert("request successfully sent");
            window.location="searchproduct.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>