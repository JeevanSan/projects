<?php
$db="marine";
$user="root";
$pass="";
$server="localhost";
$a = $_POST['p1'];



$con=mysqli_connect($server,$user,$pass,$db);
if($con){
	
	$sql="delete from notification where id='$a'";
	if($con->query($sql)===TRUE){
		echo"Record deleted";?>
		<script type="text/javascript">
            window.alert("feedback successfully deleted");
            window.location="viewnoti.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>