<?php 
$mysql_hostname = "localhost";
$mysql_user     = "root";
$mysql_password = "";
$mysql_database = "marine";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);
$a=$_POST['p1'];
$b=$_POST['p2'];
$c=$_POST['p3'];
$d=$_POST['p4'];
$e=$_POST['p5'];
$f=$_POST['p6'];


if($con){
	
	$sql="UPDATE fisherman SET fullname='$b',phone='$c',email='$d',region='$e',address='$f' where username='$a'";
	if($con->query($sql)===TRUE){
		echo"Record inserted";?>
		<script type="text/javascript">
            window.alert("update successfully sent");
            window.location="fishermandash.php";
            </script>
			<?php 
}else{
	echo"record not inserting ";
}
}
else{
	echo"connection error ";
}
?>