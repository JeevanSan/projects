<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Marine Harvesting</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="index.html">Marine Harvesting</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="admindash.php">Dashboard</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="addlocation.php">Add Location</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="viewlocation.php">View Location</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sendnoti.php">Send Notification</a>
                                        </li>
										<li class="nav-item">
                                            <a class="nav-link" href="viewnoti.php">View Notification</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="viewusers.php">View Users</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="viewmessage.php">View Message</a>
                                        </li>
										<li class="nav-item">
                                            <a class="nav-link" href="adminlogout.php">Logout</a>
                                        </li>
                                    </ul>
                              
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
		<?php
  error_reporting(0);
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['p1'])){
		$p1 = stripslashes($_REQUEST['p1']); 
		$p1 = mysqli_real_escape_string($con,$p1); 	
		$p2 = stripslashes($_REQUEST['p2']);
		$p2 = mysqli_real_escape_string($con,$p2);				
		$p3 = stripslashes($_REQUEST['p3']);
		$p3 = mysqli_real_escape_string($con,$p3);		
		$p4 = stripslashes($_REQUEST['p4']); 
		$p4 = mysqli_real_escape_string($con,$p4); 	
		$p5 = stripslashes($_REQUEST['p5']);
		$p5 = mysqli_real_escape_string($con,$p5);				
		$p6 = stripslashes($_REQUEST['p6']);
		$p6 = mysqli_real_escape_string($con,$p6);
		$p7 = date("Y-m-d H:i:s");

 $query = "INSERT INTO `location`(`region`, `location_type`, `longitude`, `latitude`, `radius`, `information`, `ldate`) VALUES  ('$p1', '$p2', '$p3', '$p4', '$p5', '$p6', '$p7')";
        $result = mysqli_query($con,$query);

        if($result){
            echo "<div class='form'><h3>You are location add successfully.</h3></div>";
           
        }
    }else{
?>
		
        <div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Add Location</h5>
                                <div class="card-body">
                                    <form action="" name="addlocation" method="post" id="validationform" data-parsley-validate="" novalidate="">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Region</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select class="form-control form-control-sm" name="p1">
                                                    <option>GUJARAT</option>
												<option>MAHARASHTRA</option>                                               
												<option>GOA</option>
												<option>KARNATAKA</option>
													<option>TAMIL NADU</option>
													<option>KERALA</option>
													<option>ANDHRA PRADESH</option>
													<option>ODISHA</option>
													<option>WEST BENGAL</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Location Type</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select class="form-control form-control-sm" name="p2">
                                                    <option>Restrected</option>
													<option>Suggested</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Longitude</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input name="p3" type="text" required="" data-parsley-maxlength="6" placeholder="Longitude" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Latitude</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input name="p4" type="text" required="" data-parsley-length="[5,10]" placeholder="Latitude" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Radius</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input name="p5" type="text" required="" data-parsley-min="6" placeholder="Radius" class="form-control">
                                            </div>
                                        </div>                                      
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Information</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <textarea name="p6" required="" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                                <button class="btn btn-space btn-secondary">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
	<?php } ?>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>