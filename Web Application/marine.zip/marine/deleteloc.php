<?php
$db="marine";
$user="root";
$pass="";
$server="localhost";
$a = $_GET['id'];



$con=mysqli_connect($server,$user,$pass,$db);
if($con){
	
	$sql="delete from location where id='$a'";
	if($con->query($sql)===TRUE){
		echo"Record deleted";?>
		<script type="text/javascript">
            window.alert("location successfully deleted");
            window.location="viewlocation.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>